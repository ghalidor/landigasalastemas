import { Component, Input } from '@angular/core';

/**
 * Bloque «SÍGUENOS»: caja azul oscura con los tres iconos grandes.
 *
 * Los enlaces salen de la sección común de redes, la misma que edita Info Sede.
 * Cada icono puede tener su imagen propia; si no, se usa la de Font Awesome.
 */
@Component({
  selector: 'app-isla-social',
  template: `
    @if (visibles.length) {
      <section class="is-social">
        <div class="is-social-caja" [class.con-fondo]="!!fondo"
             [style.background-image]="fondo ? 'url(' + fondo + ')' : null">
          <p>{{ titulo }}</p>

          <div class="is-social-iconos">
            @for (r of visibles; track r.clave) {
              <a [href]="r.enlace" target="_blank" rel="noreferrer" [title]="r.titulo">
                @if (r.imagen) {
                  <img [src]="r.imagen" [alt]="r.titulo" />
                } @else {
                  <i [class]="r.icono"></i>
                }
              </a>
            }
          </div>
        </div>
      </section>
    }
  `,
})
export class IslaSocialComponent {
  @Input() social: Record<string, string> = {};
  @Input() carpeta = '';

  /**
   * La imagen de fondo del bloque, si la sede subió una desde Info Sede
   * (socialBackground). Sin ella, el azul oscuro de siempre.
   */
  get fondo(): string {
    return this.ruta(this.social['socialBackground']);
  }

  get titulo(): string {
    return this.social['socialTitle'] || 'SÍGUENOS';
  }

  private readonly redes = [
    { clave: 'facebook', titulo: 'Facebook', icono: 'fab fa-facebook-f' },
    { clave: 'instagram', titulo: 'Instagram', icono: 'fab fa-instagram' },
    { clave: 'tiktok', titulo: 'TikTok', icono: 'fab fa-tiktok' },
  ];

  get visibles() {
    return this.redes
      .map(r => ({
        ...r,
        enlace: this.social[r.clave] ?? '',
        imagen: this.ruta(this.social[`socialIcon_${r.clave}`]),
      }))
      .filter(r => !!r.enlace);
  }

  private ruta(archivo?: string): string {
    if (!archivo) return '';

    return archivo.startsWith('http') ? archivo : `${this.carpeta}/${archivo}`;
  }
}
