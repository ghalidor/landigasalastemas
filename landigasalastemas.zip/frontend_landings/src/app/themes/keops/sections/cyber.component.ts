import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SafeImageComponent } from '@shared/safe-image.component';

export interface KeopsCyber {
  /** Si la sección se muestra. En el original era una constante del código. */
  visible?: boolean;
  title?: string;
  buttonText?: string;
  /** El PDF del cyber. Sin el, el boton no aparece. */
  pdfWeb?: string;
  /** Imagen o vídeo de la derecha. */
  mediaWeb?: string;
  /** Fondo de la franja, fijo al desplazarse. */
  backgroundWeb?: string;
  /**
   * Cómo se presenta: actual (el texto a la izquierda y la imagen a la
   * derecha), centrado (el título en grande y la imagen debajo), marco (la
   * imagen en un marco de neón) o panel (el texto sobre un panel oscuro con
   * una línea de neón). Vacío o desconocido = actual. Se elige desde el
   * gestor, con el botón de variantes de la vista previa. Usan el mismo
   * HTML: solo cambia el CSS. La imagen se ve completa en todas.
   */
  variante?: string;
}

/** Las variantes que entiende este componente. */
export const VARIANTES_CYBER_KEOPS = ['actual', 'centrado', 'marco', 'panel'] as const;
type VarianteCyberKeops = typeof VARIANTES_CYBER_KEOPS[number];

/**
 * Campaña Cyber. Va apagada por defecto y se enciende desde el gestor cuando
 * toca, igual que hacía la constante del proyecto original.
 *
 * El panel del final solo sale en el gestor. Hace falta porque la landing
 * decide si pinta la sección mirando "visible", y sin ese aviso la vista
 * previa se ve igual encendida que apagada: no habría forma de saber que el
 * ajuste existe.
 */
@Component({
  selector: 'app-keops-cyber',
  imports: [SafeImageComponent, RouterLink],
  template: `
    <section class="kp-cyber" id="cyber" [style.background-image]="fondoCss"
             [class.kp-cyber-var-centrado]="variante === 'centrado'"
             [class.kp-cyber-var-marco]="variante === 'marco'"
             [class.kp-cyber-var-panel]="variante === 'panel'">
      <div class="kp-contenido kp-cyber-fila">
        <div class="kp-cyber-texto">
          <h2>{{ data.title }}</h2>

          @if (data.pdfWeb) {
            @if (isPreview) {
              <span class="kp-boton-cyber inerte">
                {{ data.buttonText || 'Visita nuestro catálogo' }}
              </span>
            } @else {
              <a [routerLink]="['/', slug, 'cyber']" target="_blank" class="kp-boton-cyber">
                {{ data.buttonText || 'Visita nuestro catálogo' }}
              </a>
            }
          }
        </div>

        <div class="kp-cyber-media">
          @if (esVideo) {
            <video [src]="media" [muted]="true" [loop]="true" [autoplay]="true"
                   playsinline preload="auto"></video>
          } @else if (media) {
            <app-safe-image [src]="media" [alt]="data.title || ''" />
          }
        </div>
      </div>
    </section>
    @if (isPreview) {
      <aside class="kp-config">
        <h4><i class="fas fa-sliders me-2"></i>Ajustes de esta sección</h4>

        <p class="kp-config-estado" [class.activo]="visible">
          <i class="fas" [class.fa-eye]="visible" [class.fa-eye-slash]="!visible"></i>
          {{ visible
             ? 'La sección Cyber se muestra en la landing y en el menú.'
             : 'La sección Cyber está oculta: no sale en la landing ni en el menú.' }}
        </p>

        <p>
          Pídele al asistente que ponga <code>visible</code> en
          <code>{{ visible ? 'false' : 'true' }}</code> para
          {{ visible ? 'apagarla' : 'encenderla' }}.
        </p>

        <h4 class="mt-3"><i class="fas fa-image me-2"></i>Qué lleva esta sección</h4>

        <ul>
          <li><span>Título con el efecto de neón</span><code>title</code></li>
          <li><span>Texto del botón</span><code>buttonText</code></li>
          <li><span>Imagen o vídeo del lateral</span><code>mediaWeb</code></li>
          <li><span>Fondo de toda la franja</span><code>backgroundWeb</code></li>
          <li><span>El PDF que abre el botón</span><code>pdfWeb</code></li>
        </ul>

        @if (visible && !data.pdfWeb) {
          <p class="kp-aviso">
            <i class="fas fa-circle-info"></i>
            Sin PDF en <code>pdfWeb</code> el botón no aparece.
          </p>
        }

        @if (visible && !media) {
          <p class="kp-aviso">
            <i class="fas fa-circle-info"></i>
            Falta la imagen del lateral. El hueco se queda vacío.
          </p>
        }

        <p>
          Es una campaña: nace apagada y se enciende cuando toca. En el proyecto
          original esto era una constante del código y había que tocarlo para
          cambiarlo.
        </p>
      </aside>
    }
  `,
})
export class KeopsCyberComponent {
  @Input() data: KeopsCyber = {};
  @Input() carpeta = '';

  /** En el gestor se enseña siempre, encendida o no, con sus ajustes. */
  @Input() isPreview = false;

  /** Hace falta para armar la ruta del PDF. */
  @Input() slug = '';

  /** La variante en uso. Cualquier valor que no conozca cae en la actual. */
  get variante(): VarianteCyberKeops {
    const v = (this.data.variante ?? '').trim() as VarianteCyberKeops;
    return VARIANTES_CYBER_KEOPS.includes(v) ? v : 'actual';
  }

  /** Si la landing la pinta. Solo se enseña en el gestor. */
  get visible(): boolean {
    return this.data.visible === true;
  }

  get media(): string {
    return this.ruta(this.data.mediaWeb);
  }

  get esVideo(): boolean {
    return /\.(mp4|webm|ogg)$/i.test(this.media);
  }

  /** Degradado oscuro sobre la imagen, para que el texto se lea. */
  get fondoCss(): string {
    const imagen = this.ruta(this.data.backgroundWeb);
    if (!imagen) return '';

    return `linear-gradient(to right, rgba(0,0,0,.48), rgba(0,0,0,.23)), url(${imagen})`;
  }

  private ruta(archivo?: string): string {
    if (!archivo) return '';

    return archivo.startsWith('http') ? archivo : `${this.carpeta}/${archivo}`;
  }
}